export const SectionSubtitle = ({ label }: { label: string }) => {
  return <p className="text-base font-medium">{label}</p>;
};
